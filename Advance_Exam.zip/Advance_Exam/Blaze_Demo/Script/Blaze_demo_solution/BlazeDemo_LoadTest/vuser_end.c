vuser_end()
{

	/* logout */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_submit_data("logout",
		"Action=https://blazedemo.com/logout",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://blazedemo.com/home",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=_token", "Value={_token}", ENDITEM,
		LAST);

	web_custom_request("pageviews_2",
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageviews?api_key={api_key}",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://blazedemo.com/",
		"Snapshot=t8.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"8c6751ed-dc5c-4ac1-94b3-86e85a96ad19\",\"iso_time_full\":\"2024-02-24T04:22:13.589Z\",\"local_time_full\":\"Sat Feb 24 2024 09:52:13 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"3ee0f941-1117-4499-b8ce-ceb6f51b9c3e\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"f205860c-9e0d-46a9-88c7-0f5786f2471b\",\"tracker_loaded_at\":\"2024-02-24T04:22:13.585Z\",\"prodperfect_test_data\":null,\"user\":{\"uuid\":\"6afe0097-2f6c-47e2-99a5-aaa1171e7fa8\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":593,\"pixel_max\":593,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":0,\"time_on_page_ms\":4},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\":\"Win32\",\"useragen"
		"t\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"version\":\"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":593,\"width\":1280,\"scrollHeight\":593,\"ratio\":{\"height\":0.87,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"initial\":\"https://blazedemo.com/home\",\"full\":\"https://blazedemo.com/home\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:22:13.589Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referr"
		"er.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}",
		LAST);

	return 0;
}