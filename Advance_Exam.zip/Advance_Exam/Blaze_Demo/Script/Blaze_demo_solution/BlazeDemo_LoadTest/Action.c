Action()
{

	/* Home */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	lr_think_time(32);

	web_custom_request("clicks",
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/clicks?api_key={api_key}",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://blazedemo.com/",
		"Snapshot=t3.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"8d7a30a0-2eec-49cf-b244-034335059d7b\",\"iso_time_full\":\"2024-02-24T04:20:21.694Z\",\"local_time_full\":\"Sat Feb 24 2024 09:50:21 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"3ee0f941-1117-4499-b8ce-ceb6f51b9c3e\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"3177dfc6-4b49-4c94-9930-52f23e74390a\",\"tracker_loaded_at\":\"2024-02-24T04:19:49.448Z\",\"prodperfect_test_data\":null,\"user\":{\"uuid\":\"6afe0097-2f6c-47e2-99a5-aaa1171e7fa8\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":541,\"pixel_max\":541,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":32,\"time_on_page_ms\":32246},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\":\"Win32\",\"use"
		"ragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"version\":\"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":541,\"width\":1280,\"scrollHeight\":541,\"ratio\":{\"height\":0.8,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"full\":\"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:20:21.694Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_ti"
		"me_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]},\"element\":{\"class\":\"brand\",\"href\":\"https://blazedemo.com/home\",\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"brand\",\"href\":\"home\",\"unique_selector\":\".navbar-inner > .container > :nth-child(3)\"},\"node_name\":\"A\",\"tag_name\":\"A\",\"text\":null,\"title\":null,\"type\":null,\"n_parents\":[{\"class\":\"container\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"container\",\"unique_selector\":\".navbar-inner > .container\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":1},{\"class\":\"navbar-inner\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"navbar-inner\",\"unique_selector\":\".navbar-"
		"inner\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":2},{\"class\":\"navbar navbar-inverse\",\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"class\":\"navbar navbar-inverse\",\"unique_selector\":\".navbar\"},\"node_name\":\"DIV\",\"tag_name\":\"DIV\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":3},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"unique_selector\":\"body\"},\"node_name\":\"BODY\",\"tag_name\":\"BODY\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":4},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{\"lang\":\"en\",\"unique_selector\":\"html\"},\"node_name\":\"HTML\",\"tag_name\":\"HTML\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":5},{\"class\":null,\"href\":null,\"id\":null,\"name\":null,\"all_attrs\":{},\"node_name\":\"#document\",\"text\":null,\"title\":null,\"type\":null,\"nth_parent\":6}],\"selector\":\"body > div:eq(0) > div > div > a:eq("
		"2)\",\"text_content\":\"---REDACTED---\",\"cursor\":\"pointer\",\"x_position\":171,\"y_position\":1}}",
		LAST);

	web_custom_request("pageunloads",
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageunloads?api_key={api_key}",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://blazedemo.com/",
		"Snapshot=t4.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"5773a909-3465-453e-9346-b98ebcf30cef\",\"iso_time_full\":\"2024-02-24T04:20:21.752Z\",\"local_time_full\":\"Sat Feb 24 2024 09:50:21 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"3ee0f941-1117-4499-b8ce-ceb6f51b9c3e\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"3177dfc6-4b49-4c94-9930-52f23e74390a\",\"tracker_loaded_at\":\"2024-02-24T04:19:49.448Z\",\"prodperfect_test_data\":null,\"user\":{\"uuid\":\"6afe0097-2f6c-47e2-99a5-aaa1171e7fa8\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":541,\"pixel_max\":541,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":32,\"time_on_page_ms\":32304},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\":\"Win32\",\"use"
		"ragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"version\":\"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":541,\"width\":1280,\"scrollHeight\":541,\"ratio\":{\"height\":0.8,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"full\":\"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:20:21.752Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_ti"
		"me_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}",
		LAST);

	web_add_cookie("prodperfect_session={%22session_uuid%22:%223ee0f941-1117-4499-b8ce-ceb6f51b9c3e%22}; DOMAIN=blazedemo.com");

	web_add_cookie("keen={%22uuid%22:%226afe0097-2f6c-47e2-99a5-aaa1171e7fa8%22%2C%22initialReferrer%22:null}; DOMAIN=blazedemo.com");

	web_url("home", 
		"URL=https://blazedemo.com/home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	/* Login */

	web_reg_find("Text=You are logged in!", //checking the text
		LAST);

/*Correlation comment - Do not change!  Original value='2mH7L8Hegj63HY16MyIadOUeW7RrqKiSoT4LG7OJ' Name ='_token' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=_token",
		"LB= content=\"",
		"RB=\">\n\n    ",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/home*",
		LAST);

	web_submit_form("login", 
		"Snapshot=t6.inf", 
		ITEMDATA, 
		"Name=email", "Value={Username}", ENDITEM, //parameteristion
		"Name=password", "Value={Password}", ENDITEM, //parameteristion
		"Name=remember", "Value=<OFF>", ENDITEM, 
		LAST);

	return 0;
}
