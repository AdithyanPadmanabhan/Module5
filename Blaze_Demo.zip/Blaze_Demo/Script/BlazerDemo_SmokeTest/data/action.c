Action()
{

	/* Home */

	web_add_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("home", 
		"URL=https://blazedemo.com/home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	/* Login */

	return 0;
}