/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

/*Correlation comment - Do not change!  Original value='8RWMCGFX4X0IRY1GHWDM3HM5WDSJF9LP62BSDULOL3XK7WAIFGDB7EU526O1A0UPLH1S8SJP320LUXJKCHLJX1822GU1KFE80CNW6PXVZ83IOO6LJ731EN164IFVUFMC8DOGYP2MXHN47WGVB192F2PTQRQXCF95OJWAKGOH9S69DZAI5OPJW8QSPDE6LQQ9' Name ='api_key' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=api_key",
		"LB=      writeKey: \"",
		"RB=\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/blazedemo.com/*",
		LAST);

	web_url("blazedemo.com", 
		"URL=https://blazedemo.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("pageviews",
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageviews?api_key={api_key}",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://blazedemo.com/",
		"Snapshot=t2.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"750db8b3-fa3a-4d92-94dd-62a9fc7e5508\",\"iso_time_full\":\"2024-02-24T04:19:49.451Z\",\"local_time_full\":\"Sat Feb 24 2024 09:49:49 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"3ee0f941-1117-4499-b8ce-ceb6f51b9c3e\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"3177dfc6-4b49-4c94-9930-52f23e74390a\",\"tracker_loaded_at\":\"2024-02-24T04:19:49.448Z\",\"prodperfect_test_data\":null,\"user\":{\"uuid\":\"6afe0097-2f6c-47e2-99a5-aaa1171e7fa8\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":205,\"pixel_max\":205,\"ratio\":0.46,\"ratio_max\":0.46},\"time_on_page\":0,\"time_on_page_ms\":4},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\":\"Win32\",\"us"
		"eragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"version\":\"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":205,\"width\":822,\"scrollHeight\":442,\"ratio\":{\"height\":0.3,\"width\":0.64}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"full\":\"\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:19:49.452Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date"
		"_time_parser\",\"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}",
		LAST);

	return 0;
}
